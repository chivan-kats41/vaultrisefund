from django.contrib import admin
from .models import category

# Register your models here.

class categoryAdmin(admin.ModelAdmin):
    prepopulated_fields = {'slug':('category_name',)}
    list_display = ('category_name', 'slug')
    search_fields =()
    filter_horizontal =()
admin.site.register(category, categoryAdmin)
